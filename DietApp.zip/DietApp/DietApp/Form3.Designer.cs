﻿namespace DietApp
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.label1 = new System.Windows.Forms.Label();
            this.breakfast_sun = new System.Windows.Forms.Label();
            this.breakfast_mon = new System.Windows.Forms.Label();
            this.breakfast_tue = new System.Windows.Forms.Label();
            this.breakfast_wed = new System.Windows.Forms.Label();
            this.breakfast_thu = new System.Windows.Forms.Label();
            this.breakfast_fri = new System.Windows.Forms.Label();
            this.breakfast_sat = new System.Windows.Forms.Label();
            this.lunch_sun = new System.Windows.Forms.Label();
            this.lunch_mon = new System.Windows.Forms.Label();
            this.lunch_tue = new System.Windows.Forms.Label();
            this.lunch_wed = new System.Windows.Forms.Label();
            this.lunch_thu = new System.Windows.Forms.Label();
            this.lunch_fri = new System.Windows.Forms.Label();
            this.lunch_sat = new System.Windows.Forms.Label();
            this.snack_sun = new System.Windows.Forms.Label();
            this.snack_mon = new System.Windows.Forms.Label();
            this.snack_tue = new System.Windows.Forms.Label();
            this.snack_wed = new System.Windows.Forms.Label();
            this.snack_thu = new System.Windows.Forms.Label();
            this.snack_fri = new System.Windows.Forms.Label();
            this.snack_sat = new System.Windows.Forms.Label();
            this.dinner_sun = new System.Windows.Forms.Label();
            this.dinner_mon = new System.Windows.Forms.Label();
            this.dinner_tue = new System.Windows.Forms.Label();
            this.dinner_wed = new System.Windows.Forms.Label();
            this.dinner_thu = new System.Windows.Forms.Label();
            this.dinner_fri = new System.Windows.Forms.Label();
            this.dinner_sat = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(43, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 29);
            this.label1.TabIndex = 1;
            this.label1.Text = "Enter ID";
            // 
            // breakfast_sun
            // 
            this.breakfast_sun.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.breakfast_sun.AutoSize = true;
            this.breakfast_sun.BackColor = System.Drawing.Color.Transparent;
            this.breakfast_sun.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.breakfast_sun.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.breakfast_sun.Location = new System.Drawing.Point(100, 99);
            this.breakfast_sun.Name = "breakfast_sun";
            this.breakfast_sun.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.breakfast_sun.Size = new System.Drawing.Size(5, 30);
            this.breakfast_sun.TabIndex = 2;
            // 
            // breakfast_mon
            // 
            this.breakfast_mon.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.breakfast_mon.AutoSize = true;
            this.breakfast_mon.BackColor = System.Drawing.Color.Transparent;
            this.breakfast_mon.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.breakfast_mon.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.breakfast_mon.Location = new System.Drawing.Point(205, 100);
            this.breakfast_mon.Name = "breakfast_mon";
            this.breakfast_mon.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.breakfast_mon.Size = new System.Drawing.Size(5, 30);
            this.breakfast_mon.TabIndex = 3;
            // 
            // breakfast_tue
            // 
            this.breakfast_tue.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.breakfast_tue.AutoSize = true;
            this.breakfast_tue.BackColor = System.Drawing.Color.Transparent;
            this.breakfast_tue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.breakfast_tue.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.breakfast_tue.Location = new System.Drawing.Point(311, 99);
            this.breakfast_tue.Name = "breakfast_tue";
            this.breakfast_tue.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.breakfast_tue.Size = new System.Drawing.Size(5, 30);
            this.breakfast_tue.TabIndex = 4;
            // 
            // breakfast_wed
            // 
            this.breakfast_wed.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.breakfast_wed.AutoSize = true;
            this.breakfast_wed.BackColor = System.Drawing.Color.Transparent;
            this.breakfast_wed.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.breakfast_wed.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.breakfast_wed.Location = new System.Drawing.Point(415, 99);
            this.breakfast_wed.Name = "breakfast_wed";
            this.breakfast_wed.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.breakfast_wed.Size = new System.Drawing.Size(5, 30);
            this.breakfast_wed.TabIndex = 5;
            // 
            // breakfast_thu
            // 
            this.breakfast_thu.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.breakfast_thu.AutoSize = true;
            this.breakfast_thu.BackColor = System.Drawing.Color.Transparent;
            this.breakfast_thu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.breakfast_thu.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.breakfast_thu.Location = new System.Drawing.Point(521, 99);
            this.breakfast_thu.Name = "breakfast_thu";
            this.breakfast_thu.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.breakfast_thu.Size = new System.Drawing.Size(5, 30);
            this.breakfast_thu.TabIndex = 6;
            // 
            // breakfast_fri
            // 
            this.breakfast_fri.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.breakfast_fri.AutoSize = true;
            this.breakfast_fri.BackColor = System.Drawing.Color.Transparent;
            this.breakfast_fri.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.breakfast_fri.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.breakfast_fri.Location = new System.Drawing.Point(627, 99);
            this.breakfast_fri.Name = "breakfast_fri";
            this.breakfast_fri.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.breakfast_fri.Size = new System.Drawing.Size(5, 30);
            this.breakfast_fri.TabIndex = 7;
            // 
            // breakfast_sat
            // 
            this.breakfast_sat.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.breakfast_sat.AutoSize = true;
            this.breakfast_sat.BackColor = System.Drawing.Color.Transparent;
            this.breakfast_sat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.breakfast_sat.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.breakfast_sat.Location = new System.Drawing.Point(733, 99);
            this.breakfast_sat.Name = "breakfast_sat";
            this.breakfast_sat.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.breakfast_sat.Size = new System.Drawing.Size(5, 30);
            this.breakfast_sat.TabIndex = 8;
            // 
            // lunch_sun
            // 
            this.lunch_sun.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lunch_sun.AutoSize = true;
            this.lunch_sun.BackColor = System.Drawing.Color.Transparent;
            this.lunch_sun.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lunch_sun.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lunch_sun.Location = new System.Drawing.Point(100, 196);
            this.lunch_sun.Name = "lunch_sun";
            this.lunch_sun.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.lunch_sun.Size = new System.Drawing.Size(5, 30);
            this.lunch_sun.TabIndex = 9;
            // 
            // lunch_mon
            // 
            this.lunch_mon.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lunch_mon.AutoSize = true;
            this.lunch_mon.BackColor = System.Drawing.Color.Transparent;
            this.lunch_mon.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lunch_mon.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lunch_mon.Location = new System.Drawing.Point(205, 192);
            this.lunch_mon.Name = "lunch_mon";
            this.lunch_mon.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.lunch_mon.Size = new System.Drawing.Size(5, 30);
            this.lunch_mon.TabIndex = 10;
            // 
            // lunch_tue
            // 
            this.lunch_tue.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lunch_tue.AutoSize = true;
            this.lunch_tue.BackColor = System.Drawing.Color.Transparent;
            this.lunch_tue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lunch_tue.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lunch_tue.Location = new System.Drawing.Point(313, 191);
            this.lunch_tue.Name = "lunch_tue";
            this.lunch_tue.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.lunch_tue.Size = new System.Drawing.Size(5, 30);
            this.lunch_tue.TabIndex = 11;
            // 
            // lunch_wed
            // 
            this.lunch_wed.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lunch_wed.AutoSize = true;
            this.lunch_wed.BackColor = System.Drawing.Color.Transparent;
            this.lunch_wed.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lunch_wed.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lunch_wed.Location = new System.Drawing.Point(415, 191);
            this.lunch_wed.Name = "lunch_wed";
            this.lunch_wed.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.lunch_wed.Size = new System.Drawing.Size(5, 30);
            this.lunch_wed.TabIndex = 12;
            // 
            // lunch_thu
            // 
            this.lunch_thu.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lunch_thu.AutoSize = true;
            this.lunch_thu.BackColor = System.Drawing.Color.Transparent;
            this.lunch_thu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lunch_thu.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lunch_thu.Location = new System.Drawing.Point(521, 192);
            this.lunch_thu.Name = "lunch_thu";
            this.lunch_thu.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.lunch_thu.Size = new System.Drawing.Size(5, 30);
            this.lunch_thu.TabIndex = 13;
            // 
            // lunch_fri
            // 
            this.lunch_fri.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lunch_fri.AutoSize = true;
            this.lunch_fri.BackColor = System.Drawing.Color.Transparent;
            this.lunch_fri.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lunch_fri.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lunch_fri.Location = new System.Drawing.Point(627, 191);
            this.lunch_fri.Name = "lunch_fri";
            this.lunch_fri.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.lunch_fri.Size = new System.Drawing.Size(5, 30);
            this.lunch_fri.TabIndex = 14;
            // 
            // lunch_sat
            // 
            this.lunch_sat.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lunch_sat.AutoSize = true;
            this.lunch_sat.BackColor = System.Drawing.Color.Transparent;
            this.lunch_sat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lunch_sat.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lunch_sat.Location = new System.Drawing.Point(733, 191);
            this.lunch_sat.Name = "lunch_sat";
            this.lunch_sat.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.lunch_sat.Size = new System.Drawing.Size(5, 30);
            this.lunch_sat.TabIndex = 15;
            // 
            // snack_sun
            // 
            this.snack_sun.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.snack_sun.AutoSize = true;
            this.snack_sun.BackColor = System.Drawing.Color.Transparent;
            this.snack_sun.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.snack_sun.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.snack_sun.Location = new System.Drawing.Point(100, 289);
            this.snack_sun.Name = "snack_sun";
            this.snack_sun.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.snack_sun.Size = new System.Drawing.Size(5, 30);
            this.snack_sun.TabIndex = 16;
            // 
            // snack_mon
            // 
            this.snack_mon.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.snack_mon.AutoSize = true;
            this.snack_mon.BackColor = System.Drawing.Color.Transparent;
            this.snack_mon.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.snack_mon.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.snack_mon.Location = new System.Drawing.Point(204, 284);
            this.snack_mon.Name = "snack_mon";
            this.snack_mon.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.snack_mon.Size = new System.Drawing.Size(5, 30);
            this.snack_mon.TabIndex = 17;
            // 
            // snack_tue
            // 
            this.snack_tue.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.snack_tue.AutoSize = true;
            this.snack_tue.BackColor = System.Drawing.Color.Transparent;
            this.snack_tue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.snack_tue.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.snack_tue.Location = new System.Drawing.Point(311, 284);
            this.snack_tue.Name = "snack_tue";
            this.snack_tue.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.snack_tue.Size = new System.Drawing.Size(5, 30);
            this.snack_tue.TabIndex = 18;
            // 
            // snack_wed
            // 
            this.snack_wed.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.snack_wed.AutoSize = true;
            this.snack_wed.BackColor = System.Drawing.Color.Transparent;
            this.snack_wed.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.snack_wed.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.snack_wed.Location = new System.Drawing.Point(415, 284);
            this.snack_wed.Name = "snack_wed";
            this.snack_wed.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.snack_wed.Size = new System.Drawing.Size(5, 30);
            this.snack_wed.TabIndex = 19;
            // 
            // snack_thu
            // 
            this.snack_thu.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.snack_thu.AutoSize = true;
            this.snack_thu.BackColor = System.Drawing.Color.Transparent;
            this.snack_thu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.snack_thu.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.snack_thu.Location = new System.Drawing.Point(521, 284);
            this.snack_thu.Name = "snack_thu";
            this.snack_thu.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.snack_thu.Size = new System.Drawing.Size(5, 30);
            this.snack_thu.TabIndex = 20;
            // 
            // snack_fri
            // 
            this.snack_fri.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.snack_fri.AutoSize = true;
            this.snack_fri.BackColor = System.Drawing.Color.Transparent;
            this.snack_fri.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.snack_fri.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.snack_fri.Location = new System.Drawing.Point(627, 284);
            this.snack_fri.Name = "snack_fri";
            this.snack_fri.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.snack_fri.Size = new System.Drawing.Size(5, 30);
            this.snack_fri.TabIndex = 21;
            // 
            // snack_sat
            // 
            this.snack_sat.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.snack_sat.AutoSize = true;
            this.snack_sat.BackColor = System.Drawing.Color.Transparent;
            this.snack_sat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.snack_sat.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.snack_sat.Location = new System.Drawing.Point(733, 284);
            this.snack_sat.Name = "snack_sat";
            this.snack_sat.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.snack_sat.Size = new System.Drawing.Size(5, 30);
            this.snack_sat.TabIndex = 22;
            // 
            // dinner_sun
            // 
            this.dinner_sun.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dinner_sun.AutoSize = true;
            this.dinner_sun.BackColor = System.Drawing.Color.Transparent;
            this.dinner_sun.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dinner_sun.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dinner_sun.Location = new System.Drawing.Point(100, 376);
            this.dinner_sun.Name = "dinner_sun";
            this.dinner_sun.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.dinner_sun.Size = new System.Drawing.Size(5, 30);
            this.dinner_sun.TabIndex = 23;
            // 
            // dinner_mon
            // 
            this.dinner_mon.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dinner_mon.AutoSize = true;
            this.dinner_mon.BackColor = System.Drawing.Color.Transparent;
            this.dinner_mon.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dinner_mon.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dinner_mon.Location = new System.Drawing.Point(204, 376);
            this.dinner_mon.Name = "dinner_mon";
            this.dinner_mon.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.dinner_mon.Size = new System.Drawing.Size(5, 30);
            this.dinner_mon.TabIndex = 24;
            // 
            // dinner_tue
            // 
            this.dinner_tue.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dinner_tue.AutoSize = true;
            this.dinner_tue.BackColor = System.Drawing.Color.Transparent;
            this.dinner_tue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dinner_tue.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dinner_tue.Location = new System.Drawing.Point(311, 374);
            this.dinner_tue.Name = "dinner_tue";
            this.dinner_tue.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.dinner_tue.Size = new System.Drawing.Size(5, 30);
            this.dinner_tue.TabIndex = 25;
            // 
            // dinner_wed
            // 
            this.dinner_wed.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dinner_wed.AutoSize = true;
            this.dinner_wed.BackColor = System.Drawing.Color.Transparent;
            this.dinner_wed.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dinner_wed.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dinner_wed.Location = new System.Drawing.Point(415, 374);
            this.dinner_wed.Name = "dinner_wed";
            this.dinner_wed.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.dinner_wed.Size = new System.Drawing.Size(5, 30);
            this.dinner_wed.TabIndex = 26;
            // 
            // dinner_thu
            // 
            this.dinner_thu.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dinner_thu.AutoSize = true;
            this.dinner_thu.BackColor = System.Drawing.Color.Transparent;
            this.dinner_thu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dinner_thu.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dinner_thu.Location = new System.Drawing.Point(521, 376);
            this.dinner_thu.Name = "dinner_thu";
            this.dinner_thu.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.dinner_thu.Size = new System.Drawing.Size(5, 30);
            this.dinner_thu.TabIndex = 27;
            // 
            // dinner_fri
            // 
            this.dinner_fri.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dinner_fri.AutoSize = true;
            this.dinner_fri.BackColor = System.Drawing.Color.Transparent;
            this.dinner_fri.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dinner_fri.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dinner_fri.Location = new System.Drawing.Point(627, 376);
            this.dinner_fri.Name = "dinner_fri";
            this.dinner_fri.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.dinner_fri.Size = new System.Drawing.Size(5, 30);
            this.dinner_fri.TabIndex = 28;
            // 
            // dinner_sat
            // 
            this.dinner_sat.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dinner_sat.AutoSize = true;
            this.dinner_sat.BackColor = System.Drawing.Color.Transparent;
            this.dinner_sat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dinner_sat.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dinner_sat.Location = new System.Drawing.Point(733, 376);
            this.dinner_sat.Name = "dinner_sat";
            this.dinner_sat.Padding = new System.Windows.Forms.Padding(0, 5, 5, 5);
            this.dinner_sat.Size = new System.Drawing.Size(5, 30);
            this.dinner_sat.TabIndex = 29;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(349, 22);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(39, 31);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 30;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel1.Controls.Add(this.dinner_sat);
            this.panel1.Controls.Add(this.dinner_fri);
            this.panel1.Controls.Add(this.dinner_thu);
            this.panel1.Controls.Add(this.dinner_wed);
            this.panel1.Controls.Add(this.dinner_tue);
            this.panel1.Controls.Add(this.dinner_mon);
            this.panel1.Controls.Add(this.dinner_sun);
            this.panel1.Controls.Add(this.snack_sat);
            this.panel1.Controls.Add(this.snack_fri);
            this.panel1.Controls.Add(this.snack_thu);
            this.panel1.Controls.Add(this.snack_wed);
            this.panel1.Controls.Add(this.snack_tue);
            this.panel1.Controls.Add(this.snack_mon);
            this.panel1.Controls.Add(this.snack_sun);
            this.panel1.Controls.Add(this.lunch_sat);
            this.panel1.Controls.Add(this.lunch_fri);
            this.panel1.Controls.Add(this.lunch_thu);
            this.panel1.Controls.Add(this.lunch_wed);
            this.panel1.Controls.Add(this.lunch_tue);
            this.panel1.Controls.Add(this.lunch_mon);
            this.panel1.Controls.Add(this.lunch_sun);
            this.panel1.Controls.Add(this.breakfast_sat);
            this.panel1.Controls.Add(this.breakfast_fri);
            this.panel1.Controls.Add(this.breakfast_thu);
            this.panel1.Controls.Add(this.breakfast_wed);
            this.panel1.Controls.Add(this.breakfast_tue);
            this.panel1.Controls.Add(this.breakfast_mon);
            this.panel1.Controls.Add(this.breakfast_sun);
            this.panel1.Location = new System.Drawing.Point(48, 68);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(839, 472);
            this.panel1.TabIndex = 31;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(306, 22);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(37, 31);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 33;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.maskedTextBox1.BeepOnError = true;
            this.maskedTextBox1.CutCopyMaskFormat = System.Windows.Forms.MaskFormat.IncludePrompt;
            this.maskedTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maskedTextBox1.InsertKeyMode = System.Windows.Forms.InsertKeyMode.Overwrite;
            this.maskedTextBox1.Location = new System.Drawing.Point(148, 22);
            this.maskedTextBox1.Mask = "000000";
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.PromptChar = '0';
            this.maskedTextBox1.ResetOnPrompt = false;
            this.maskedTextBox1.ResetOnSpace = false;
            this.maskedTextBox1.Size = new System.Drawing.Size(152, 31);
            this.maskedTextBox1.TabIndex = 34;
            this.maskedTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.maskedTextBox1.TextMaskFormat = System.Windows.Forms.MaskFormat.IncludePrompt;
            this.maskedTextBox1.ValidatingType = typeof(int);
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.BackColor = System.Drawing.Color.Chocolate;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button1.Location = new System.Drawing.Point(854, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(62, 24);
            this.button1.TabIndex = 74;
            this.button1.Text = "Log Out";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(928, 552);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.maskedTextBox1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label1);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MyDietPlan";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form3_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.Button button1;
        internal System.Windows.Forms.Label breakfast_sun;
        internal System.Windows.Forms.Label breakfast_mon;
        internal System.Windows.Forms.Label breakfast_tue;
        internal System.Windows.Forms.Label breakfast_wed;
        internal System.Windows.Forms.Label breakfast_thu;
        internal System.Windows.Forms.Label breakfast_fri;
        internal System.Windows.Forms.Label breakfast_sat;
        internal System.Windows.Forms.Label lunch_sun;
        internal System.Windows.Forms.Label lunch_mon;
        internal System.Windows.Forms.Label lunch_tue;
        internal System.Windows.Forms.Label lunch_wed;
        internal System.Windows.Forms.Label lunch_thu;
        internal System.Windows.Forms.Label lunch_fri;
        internal System.Windows.Forms.Label lunch_sat;
        internal System.Windows.Forms.Label snack_sun;
        internal System.Windows.Forms.Label snack_mon;
        internal System.Windows.Forms.Label snack_tue;
        internal System.Windows.Forms.Label snack_wed;
        internal System.Windows.Forms.Label snack_thu;
        internal System.Windows.Forms.Label snack_fri;
        internal System.Windows.Forms.Label snack_sat;
        internal System.Windows.Forms.Label dinner_sun;
        internal System.Windows.Forms.Label dinner_mon;
        internal System.Windows.Forms.Label dinner_tue;
        internal System.Windows.Forms.Label dinner_wed;
        internal System.Windows.Forms.Label dinner_thu;
        internal System.Windows.Forms.Label dinner_fri;
        internal System.Windows.Forms.Label dinner_sat;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}